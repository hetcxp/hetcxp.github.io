<?php
define('CLI_SCRIPT', true);
require('/Users/hectorteran/Dev/moodle-dev/public/config.php');
require_once($CFG->dirroot.'/course/lib.php');
require_once($CFG->dirroot.'/course/modlib.php');
require_once($CFG->libdir.'/filelib.php');

$assets_dir = '/Users/hectorteran/Documents/curso_discriminación/moodle_assets';

// 1. Crear el curso
$record = new stdClass();
$record->fullname = 'Discriminación y Sesgos Inconscientes';
$record->shortname = 'discriminacion_' . time();
$record->category = 1;
$record->format = 'topics';
$record->numsections = 6; // Intro + 4 Casos + Conclusion
$course = create_course($record);

echo "✅ Curso creado: " . $course->fullname . " (ID: " . $course->id . ")\n";

// Funciones Helper (Adaptadas de deploy_moodle_native.php)
function add_moodle_page($course, $sectionnum, $title, $content) {
    global $DB, $CFG;
    $module = $DB->get_record('modules', ['name' => 'page']);
    
    $page = new stdClass();
    $page->course = $course->id;
    $page->name = $title;
    $page->intro = '';
    $page->introformat = FORMAT_HTML;
    $page->content = $content;
    $page->contentformat = FORMAT_HTML;
    $page->display = 5;
    $page->displayoptions = '';
    $page->revision = 1;
    $page->timemodified = time();
    $page->id = $DB->insert_record('page', $page);
    
    $cm = new stdClass();
    $cm->course = $course->id;
    $cm->module = $module->id;
    $cm->instance = $page->id;
    $cm->section = 0;
    $cm->added = time();
    $cm->score = 0;
    $cm->indent = 0;
    $cm->visible = 1;
    $cm->id = $DB->insert_record('course_modules', $cm);
    
    $section = $DB->get_record('course_sections', ['course' => $course->id, 'section' => $sectionnum]);
    if (!$section) {
        $section = new stdClass();
        $section->course = $course->id;
        $section->section = $sectionnum;
        $section->summary = '';
        $section->summaryformat = FORMAT_HTML;
        $section->sequence = $cm->id;
        $section->id = $DB->insert_record('course_sections', $section);
    } else {
        $section->sequence = empty($section->sequence) ? $cm->id : $section->sequence . ',' . $cm->id;
        $DB->update_record('course_sections', $section);
    }
    
    $cm->section = $section->id;
    $DB->update_record('course_modules', $cm);
    rebuild_course_cache($course->id, true);
    return $cm->id;
}

function add_moodle_h5pactivity($course, $sectionnum, $title, $filepath, $intro = '') {
    global $DB, $CFG;
    $module = $DB->get_record('modules', ['name' => 'h5pactivity']);
    if (!$module) {
        die("Error: El plugin mod_h5pactivity no está instalado en este Moodle.\n");
    }
    
    if (!file_exists($filepath)) {
        echo "⚠️ Advertencia: El archivo H5P no existe ($filepath). Omitiendo...\n";
        return null;
    }
    
    $h5pactivity = new stdClass();
    $h5pactivity->course = $course->id;
    $h5pactivity->name = $title;
    $h5pactivity->intro = $intro;
    $h5pactivity->introformat = FORMAT_HTML;
    $h5pactivity->timecreated = time();
    $h5pactivity->timemodified = time();
    $h5pactivity->displayopt = 15;
    $h5pactivity->id = $DB->insert_record('h5pactivity', $h5pactivity);
    
    $cm = new stdClass();
    $cm->course = $course->id;
    $cm->module = $module->id;
    $cm->instance = $h5pactivity->id;
    $cm->section = 0;
    $cm->added = time();
    $cm->score = 0;
    $cm->indent = 0;
    $cm->visible = 1;
    $cm->id = $DB->insert_record('course_modules', $cm);
    
    $section = $DB->get_record('course_sections', ['course' => $course->id, 'section' => $sectionnum]);
    if (!$section) {
        $section = new stdClass();
        $section->course = $course->id;
        $section->section = $sectionnum;
        $section->summary = '';
        $section->summaryformat = FORMAT_HTML;
        $section->sequence = $cm->id;
        $section->id = $DB->insert_record('course_sections', $section);
    } else {
        $section->sequence = empty($section->sequence) ? $cm->id : $section->sequence . ',' . $cm->id;
        $DB->update_record('course_sections', $section);
    }
    
    $cm->section = $section->id;
    $DB->update_record('course_modules', $cm);
    
    $context = context_module::instance($cm->id);
    $fs = get_file_storage();
    $file_record = array(
        'contextid' => $context->id,
        'component' => 'mod_h5pactivity',
        'filearea'  => 'package',
        'itemid'    => 0,
        'filepath'  => '/',
        'filename'  => basename($filepath),
        'timecreated' => time(),
        'timemodified' => time(),
    );
    
    $fs->create_file_from_pathname($file_record, $filepath);
    rebuild_course_cache($course->id, true);
    return $cm->id;
}

function update_section_name($course_id, $sectionnum, $name) {
    global $DB;
    if ($section = $DB->get_record('course_sections', ['course' => $course_id, 'section' => $sectionnum])) {
        $section->name = $name;
        $DB->update_record('course_sections', $section);
    }
}

// ==========================================
// 2. Inyección de Secciones y Contenidos
// ==========================================

// Tema 1: Introducción
update_section_name($course->id, 1, 'Introducción');
$intro_html = file_get_contents($assets_dir . '/tema_0_introduccion.html');
add_moodle_page($course, 1, '📘 Introducción al Curso', $intro_html);
echo "✅ Tema 1: Introducción añadido.\n";

// Tema 2: Caso 1
update_section_name($course->id, 2, 'Caso 1: El Proceso de Contratación Seguro');
$c1_deep = file_get_contents($assets_dir . '/tema_1_deepdive.html');
add_moodle_page($course, 2, '📘 Análisis del Escenario (A fondo)', $c1_deep);
add_moodle_h5pactivity($course, 2, '⚙️ Escenario Interactivo y Cuestionario (Caso 1)', $assets_dir . '/mod1_quiz.h5p');
$c1_html = file_get_contents($assets_dir . '/tema_1_infografia.html');
add_moodle_page($course, 2, '📊 Infografía Resumen (Caso 1)', $c1_html);
echo "✅ Tema 2: Caso 1 añadido.\n";

// Tema 3: Caso 2
update_section_name($course->id, 3, 'Caso 2: Dinámicas de Equipo');
$c2_deep = file_get_contents($assets_dir . '/tema_2_deepdive.html');
add_moodle_page($course, 3, '📘 Análisis del Escenario (A fondo)', $c2_deep);
add_moodle_h5pactivity($course, 3, '⚙️ Escenario Interactivo y Cuestionario (Caso 2)', $assets_dir . '/mod2_quiz.h5p');
$c2_html = file_get_contents($assets_dir . '/tema_2_infografia.html');
add_moodle_page($course, 3, '📊 Infografía Resumen (Caso 2)', $c2_html);
echo "✅ Tema 3: Caso 2 añadido.\n";

// Tema 4: Caso 3
update_section_name($course->id, 4, 'Caso 3: La Decisión Rápida de Liderazgo');
$c3_deep = file_get_contents($assets_dir . '/tema_3_deepdive.html');
add_moodle_page($course, 4, '📘 Análisis del Escenario (A fondo)', $c3_deep);
add_moodle_h5pactivity($course, 4, '⚙️ Escenario Interactivo y Cuestionario (Caso 3)', $assets_dir . '/mod3_quiz.h5p');
$c3_html = file_get_contents($assets_dir . '/tema_3_infografia.html');
add_moodle_page($course, 4, '📊 Infografía Resumen (Caso 3)', $c3_html);
echo "✅ Tema 4: Caso 3 añadido.\n";

// Tema 5: Caso 4
update_section_name($course->id, 5, 'Caso 4: Estrategias de Inclusión');
$c4_deep = file_get_contents($assets_dir . '/tema_4_deepdive.html');
add_moodle_page($course, 5, '📘 Análisis del Escenario (A fondo)', $c4_deep);
add_moodle_h5pactivity($course, 5, '⚙️ Escenario Interactivo y Cuestionario (Caso 4)', $assets_dir . '/mod4_quiz.h5p');
$c4_html = file_get_contents($assets_dir . '/tema_4_infografia.html');
add_moodle_page($course, 5, '📊 Infografía Resumen (Caso 4)', $c4_html);
echo "✅ Tema 5: Caso 4 añadido.\n";

// Tema 6: Conclusión
update_section_name($course->id, 6, 'Conclusión');
$concl_html = file_get_contents($assets_dir . '/tema_5_conclusion.html');
add_moodle_page($course, 6, '📘 Conclusión del Curso', $concl_html);
echo "✅ Tema 6: Conclusión añadida.\n";

echo "\n🚀 ¡Despliegue automático completado!\n";
echo "URL del curso: http://localhost:8000/course/view.php?id=" . $course->id . "\n";
