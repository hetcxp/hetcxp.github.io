# Estructura del Curso

## Introducción

Imagina llegar a tu oficina cada mañana sabiendo que tus ideas, tu talento y tu identidad son valorados exactamente por lo que son. Lamentablemente, esa no es la realidad para muchos profesionales. A menudo, decisiones críticas que definen la trayectoria de las personas y de la organización se toman basándose en hilos invisibles: sesgos, suposiciones no cuestionadas y prejuicios ocultos. 

Este curso te invita a ponerte en los zapatos de quienes viven estas realidades. A través de cuatro historias inmersivas —desde contrataciones viciadas hasta microagresiones normalizadas y fallos garrafales en el liderazgo—, desentrañaremos cómo opera la discriminación en el día a día corporativo.

**Objetivo General:** Emprenderemos un viaje para destapar estos puntos ciegos. Aprenderás a identificar, analizar y mitigar los sesgos inconscientes, armándote con herramientas tácticas para convertirte en un agente de cambio y construir, en la práctica, un ecosistema laboral genuinamente inclusivo y equitativo.

---

## Contenido: Casos de Estudio

### Caso 1: El Proceso de Contratación Seguro

#### Evento 1: Captar la atención  
**Lectura de Escenario Inmersivo:** La historia de Javier, un reclutador junior que presencia cómo un comité de directivos descarta a candidatos altamente calificados (por edad, nombre extranjero y vestimenta) y favorece a un candidato menos preparado solo por afinidad.

#### Evento 2: Informar al aprendiz  
**Objetivo del caso:** Identificar los principales sesgos inconscientes (Racial, Edad, Religioso/Cultural, Afinidad, etc.) y aplicar los 5 pasos positivos para erradicarlos.

#### Evento 9: Mejorar la retención  
**Infografía Descargable:** Los 5 Pasos para Evitar Sesgos (Contratación Moderna, Hablar en Privado, Opiniones Diversas, Tomar Acción, Educación y Reflexión).

---

### Caso 2: Dinámicas de Equipo y el Cumplido Incomprendido

#### Evento 1: Captar la atención  
**Lectura de Escenario Inmersivo:** La historia de Carlos, un analista que recibe un dardo disfrazado de halago ("casi me da vergüenza lo bueno que es") por parte de su líder María, basado en asunciones erróneas sobre su origen étnico frente al silencio del equipo.

#### Evento 2: Informar al aprendiz  
**Conceptos clave:** Microagresiones, Discriminación por Asociación y Percepción. Aplicación del Método CPR (Content, Pattern, Relationship).

#### Evento 9: Mejorar la retención  
**Infografía Descargable:** Microagresiones y Método CPR (Tipos comunes, Impacto oculto, Método CPR, Barreras a superar).

---

### Caso 3: La Decisión Rápida de Liderazgo

#### Evento 1: Captar la atención  
**Lectura de Escenario Inmersivo:** La historia de Elena, una experta técnica de 65 años cuya valiosa advertencia sobre una inversión de 5 millones de dólares es ignorada por el equipo de liderazgo debido a su edad y género, resultando en un fracaso millonario por priorizar la rapidez y la cohesión.

#### Evento 2: Informar el objetivo  
**Objetivo:** Identificar sesgos de conformidad, género y edad en decisiones grupales. Comprender la importancia de escuchar voces divergentes para evitar juicios apresurados.

#### Evento 9: Mejorar la retención  
**Infografía Descargable:** Anulación de Sesgos en Decisiones (Sesgos comunes, Consecuencias y Estrategias para evitarlos).

---

### Caso 4: Construyendo el Futuro (Estrategias de Retención e Inclusión)

#### Evento 1: Captar la atención
**Lectura de Escenario Inmersivo:** La historia de Luis, un empleado con discapacidad visual que tras denunciar acoso en forma de "bromas inofensivas", es excluido de un proyecto clave por su gerente como castigo, llevándolo a renunciar.

#### Evento 2: Informar al aprendiz
**Objetivo del módulo:** Diferenciar Acoso (Harassment) de Victimización, y revisar las 4 estrategias conductuales clave que todo líder debe aplicar para fomentar la inclusión y evitar la fuga de talento.

#### Evento 9: Mejorar la retención
**Infografía Descargable:** Estrategias Conductuales e Inclusión (Conceptos Clave, Impacto Oculto y Acciones del Líder).

---

## Conclusión General

Nuestra travesía termina aquí, pero el verdadero trabajo apenas comienza. Hemos caminado junto a Javier, presenciando la injusticia de un comité cerrado; hemos sentido el desconcierto de Carlos ante un cumplido que escondía un prejuicio; compartimos la frustración de Elena al ver ignorada su experiencia, y observamos con impotencia cómo el talento de Luis se escapaba por la puerta de atrás. Estas no son solo historias aisladas; son un reflejo de las grietas que rompen la confianza en las organizaciones.

A lo largo de este viaje no fuimos solo espectadores, aprendimos que el destino de estas historias se puede reescribir. Nos equipamos con los 5 pasos positivos para reclutar con justicia, dominamos el método CPR para desarmar microagresiones y descubrimos estrategias para retener el talento abrazando la diversidad. Hemos logrado nuestro **objetivo general**: ahora posees la capacidad de ver lo invisible y el coraje de actuar. En tus manos queda el poder de transformar estas lecciones en acción, asegurando que el próximo capítulo en tu entorno laboral sea una historia de genuina inclusión y respeto mutuo.