# Módulo: Valor Diversidad y Anulación de Sesgos en Decisiones de Liderazgo  
## Caso 3: La Decisión Rápida de Liderazgo  

### 1. Captar la atención  
**Lectura de Escenario Inmersivo:**  
*Conoce a Elena, una experta técnica de 65 años con décadas de experiencia en el sector.*

*En una tensa reunión de liderazgo, el reloj marca que solo quedan 24 horas para aprobar una inversión crítica de 5 millones de dólares.*

*El CEO propone una ruta arriesgada y el grupo, ansioso por terminar, asiente de inmediato.*

*Elena levanta la mano y advierte con datos claros que existe una alternativa mucho más segura, pero sus palabras flotan en el vacío.*

*Los directivos más jóvenes asumen que "sus ideas ya están obsoletas" y que, por ser mujer, "es demasiado cautelosa".*

*Deciden ignorarla, votan por la idea del líder para no generar conflictos, y al mes siguiente, la inversión se convierte en un fracaso millonario que pudo evitarse con solo haberla escuchado.*

### 2. Informar el objetivo  
**Objetivo:**  
- Identificar cómo los sesgos de conformidad, género y edad pueden llevar a decisiones sesgadas.  
- Comprender la importancia de la diversidad para evitar juicios apresurados (snap judgments) y mejorar la toma de decisiones.  

### 3. Estimular el recuerdo  
**Actividad de Autorreflexión (Flip Card):**  
- ¿Has participado en decisiones grupales donde tuvo peso la opinión de la mayoría sobre la opinión experta? (Ingresa tus reflexiones y presiona revelar para comparar).
- *Respuesta esperada:* A menudo la presión por cohesión hace que ignoremos a voces divergentes, arriesgando la calidad del trabajo.

### 4. Presentar el contenido  
**Caso detallado:**  
- **Contexto:** Un equipo de liderazgo (5 miembros) debe decidir sobre una inversión de 5 millones de dólares.  
- **Situación:** Un experto externo (mujer de 65 años) sugiere una alternativa con menor riesgo, pero su opinión es ignorada.  
- **Razones para ignorarla:**  
  - **Sesgo de Conformidad:** El grupo prefiere seguir la línea del líder.  
  - **Sesgo de Género:** Se subestima su experiencia por su género.  
  - **Sesgo de Edad:** Se asume que su conocimiento es obsoleto.  
- **Resultado:** La decisión rápida lleva a una pérdida millonaria.  

### 5. Proporcionar guía de aprendizaje  
**Análisis del caso y acciones:**  
- Para anular sesgos grupales, es imperativo consultar opiniones diversas antes de tomar una decisión final (Opinions).
- Detener juicios apresurados solicitando explícitamente puntos de vista divergentes.

### 6. Provocar el desempeño  
**Escenario Interactivo:**  
Eres el líder del equipo. Al notar que la opinión de la experta de 65 años fue ignorada y todos empiezan a darte la razón automáticamente, tienes 1 minuto para decidir tu próxima acción. ¿Qué haces?
a) Aceptas el apoyo unánime del grupo y procedes con tu idea original para ahorrar tiempo.
b) Pausas la reunión y solicitas explícitamente a dos miembros del equipo que argumenten a favor de la propuesta de la experta antes de votar.
c) Despiden a la experta por causar retrasos en la decisión.

### 7. Ofrecer retroalimentación  
**Retroalimentación inmediata:**  
- **Si eligió a):** *Incorrecto.* Has cedido al Sesgo de Conformidad y a un juicio apresurado, arriesgando 5 millones de dólares por no escuchar una perspectiva diversa.
- **Si eligió b):** *Correcto.* Obligar al grupo a explorar deliberadamente la perspectiva marginada anula el Sesgo de Conformidad y mitiga el sesgo de edad y género.
- **Si eligió c):** *Incorrecto.* Actitud perjudicial que refleja un grave sesgo de edad y fomenta un entorno dictatorial.

### 8. Evaluar el desempeño  
**Cuestionario Interactivo (Selección Simple):**  

1. Cuando el equipo de liderazgo descarta la opinión de la experta externa asumiendo que su conocimiento está desactualizado exclusivamente por tener 65 años, ¿qué sesgo está operando principalmente?
   - a) Sesgo de Confirmación
   - b) Sesgo de Edad *(Correcta)*
   - c) Sesgo de Afinidad

2. La tendencia del grupo a alinearse rápidamente con la postura inicial del líder, ignorando alternativas viables para no romper la cohesión y tomar la decisión rápido, se conoce como:
   - a) Sesgo de Conformidad *(Correcta)*
   - b) Sesgo de Género
   - c) Efecto Espectador

3. Subestimar la capacidad de análisis técnico de la experta debido a que es mujer, otorgando más credibilidad inmediata a las opiniones del resto del equipo directivo, es un claro ejemplo de:
   - a) Discriminación por Asociación
   - b) Sesgo de Género *(Correcta)*
   - c) Discriminación por Percepción

### 9. Mejorar la retención  
**Infografía Resumen: Anulación de Sesgos en Decisiones**  
*(Para descargar y mantener visible en el área de trabajo)*  
```mermaid
mindmap
  root((Decisiones sin
    Sesgos))
    Sesgos Comunes
      Conformidad
      Edad
      Género
    Consecuencias
      Juicios apresurados
      Pérdidas de calidad
    Estrategias
      Consultar opiniones diversas
      Solicitar visiones divergentes
      Pausar antes de decidir
```

**Checklist de Toma de Decisiones:**  
- Descargable con una pauta: "¿Estamos priorizando la cohesión o la calidad de la decisión?" Promover la cultura de escuchar a todos.
