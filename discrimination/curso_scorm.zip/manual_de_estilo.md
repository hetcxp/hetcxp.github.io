# Manual de Estilo - Curso Discriminación (Premium Modern)

Basado en un diseño corporativo premium con toques modernos (*Glassmorphism*).

## Tipografía
- **Títulos (H1, H2, H3):** `'Outfit', 'Inter', sans-serif`, Peso `700` o superior (Bold/ExtraBold). Tracking apretado (`-0.02em`).
- **Cuerpo de texto y Familia principal:** `'Inter', -apple-system, sans-serif`, Peso `400` (Regular), tamaño base `16px`, altura de línea `1.5`.

## Paleta de Colores
- **Brand Primary:** `#0A66C2` (Azul Vibrante)
  - Hover: `#084E96`
  - Active: `#05366A`
- **Success / Completado:** `#0F8246`
- **Fondos (Backgrounds):**
  - Fondo principal: `#F3F5F9` (Gris sutil azulado) con gradientes de malla suaves en áreas específicas.
  - Fondo de superficies (Glassmorphism): `rgba(255, 255, 255, 0.7)` o `rgba(255, 255, 255, 0.9)`.
- **Texto (Neutrals):**
  - Texto principal: `#1F2937`
  - Texto secundario: `#4B5563`
- **Bordes y Líneas:** `rgba(255, 255, 255, 0.4)` (Efecto cristal)
- **Superposición (Overlay):** `rgba(15, 23, 42, 0.6)` (Azul marino translúcido)

## Sombras y Elevación (Depth)
- **Tarjetas (Cards):**
  `box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.01);`
- **Modales:**
  `box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15);`
- **Efecto Glow (Botones y destacados):**
  `box-shadow: 0 0 15px rgba(10, 102, 194, 0.4);`

## Interacción
- **Bordes (Border-radius):** `12px` base, `16px` para contenedores grandes (`-lg`). `50px` (pill) en botones primarios.
- **Glassmorphism:** Uso intensivo de `backdrop-filter: blur(12px)`.
- **Transiciones:** Suaves y elásticas (`transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1)`). Hover con elevación (`transform: translateY(-8px)` en tarjetas, `-2px` en botones).
- **Botones Deshabilitados:**
  - Fondo: `#E5E7EB`
  - Texto: `#9CA3AF`
  - Cursor: `not-allowed`
