## Caso 1: El Proceso de Contratación Seguro (Análisis Exhaustivo)

### **Evento 1: Captar la atención**  
**Lectura de Escenario Inmersivo:**  
*Conoce a Javier, un reclutador junior sentado en silencio en la sala de juntas.*

*Frente a él, un comité de directivos —todos con un perfil casi idéntico— acaba de entrevistar a tres finalistas para un puesto gerencial.*

*Javier observó cómo al Candidato A, joven y de la misma universidad que el gerente, le hacían preguntas fáciles, asumiendo su talento solo por simpatía.*

*Luego vio cómo a la Candidata B, una mujer de 55 años con un currículum brillante, la acorralaron buscando errores para justificar que "no tendría energía".*

*Finalmente, escuchó cómo descartaban al Candidato C por usar vestimenta tradicional y tener un nombre extranjero, asumiendo que "no encajaría en la cultura".*

*Sabiendo que el comité ya se inclinó injustamente por el Candidato A, Javier siente un nudo en el estómago: ¿debería alzar la voz o quedarse callado para no incomodar a sus jefes?*

### **Evento 2: Informar al aprendiz**  
**Objetivo del caso:**  
En este caso aprenderás a identificar **todos** los principales sesgos inconscientes (Racial, Edad, Religioso/Cultural, Afinidad, Atribución, Belleza, Confirmación, Género y Conformidad) que contaminan la toma de decisiones, y cómo aplicar los **5 pasos positivos** para erradicarlos.

### **Evento 3: Estimular el recuerdo**  
**Reflexión inicial:**  
La premisa fundamental es aceptar la verdad incómoda: **todos tenemos sesgos**. Se forman desde nuestra infancia por padres, medios y cultura. Aceptar esto no te hace mala persona, pero ¿qué harías tú si estuvieras en los zapatos del reclutador junior viendo que se está cometiendo una injusticia múltiple?

### **Evento 4: Presentar el contenido**  
**Análisis de los 9 Sesgos en el Escenario:**  
1. **Sesgo de Afinidad (Affinity Bias / Name Bias):** El gerente adora al Candidato A por ser de su universidad.  
2. **Sesgo de Atribución (Attribution Bias):** Asumir que el Candidato A tiene buena ética laboral solo porque comparte el mismo perfil que el gerente.  
3. **Sesgo de Belleza (Beauty Bias):** Favorecer al Candidato A inconscientemente por su atractivo físico en lugar de su personalidad.  
4. **Sesgo de Edad (Age Bias):** Dudar de la "energía" de la Candidata B exclusivamente por tener 55 años.  
5. **Sesgo de Género (Gender Bias):** Preferencia sutil del comité hacia el liderazgo masculino (Candidato A) frente a la directiva femenina (Candidata B).  
6. **Sesgo de Confirmación (Confirmation Bias):** Hacer preguntas difíciles a la Candidata B y fáciles al Candidato A para "confirmar" lo que ya pensaban de ellos antes de empezar.  
7. **Sesgo Racial (Racial Bias):** Descartar inicialmente al Candidato C por tener un nombre extranjero.  
8. **Sesgo Religioso/Cultural:** Asumir que el Candidato C no encajará por usar vestimenta cultural tradicional.  
9. **Sesgo de Conformidad (Conformity Bias):** El reclutador junior cambia su opinión o se queda callado únicamente para coincidir con el grupo y ser aceptado.

### **Evento 5: Proporcionar guía de aprendizaje**  
**Los 5 Pasos Positivos para Eliminar Sesgos (Acciones Estructurales y Conductuales):**  
Para evitar estas catástrofes de contratación, se deben implementar las siguientes 5 medidas:  
- **Contratación Moderna (Hire with a modern outlook):** Estandarizar las entrevistas, hacer las mismas preguntas a todos y usar una rúbrica ciega, cuidando las palabras de los anuncios.  
- **Hablar (Speak up):** Fomentar un diálogo abierto. El reclutador junior debe señalar lo que ve en privado para educar a los gerentes, no para avergonzarlos.  
- **Opiniones Diversas (Opinions):** El comité es homogéneo. Deben consultar la decisión con un grupo diverso para anular los sesgos individuales.  
- **Tomar Acción (Action):** Hacer preguntas incisivas e indagar los verdaderos motivos cuando sospeches que un prejuicio influyó en el rechazo de la Candidata B y C.  
- **Educación (Education):** Investigar sobre prejuicios y hacer introspección para descubrir en qué áreas los gerentes permitieron que la cultura y los medios nublaran su juicio.

### **Evento 6: Provocar el desempeño**  
**Escenario Interactivo de Decisión (Simulador H5P):**  
Eres el reclutador junior en esa sala. Observas el Sesgo de Afinidad y Confirmación hacia el Candidato A, y el Sesgo de Conformidad operando en el resto del equipo. Tienes que elegir cómo proceder usando los 5 pasos positivos:  

**Opción A:** En medio de la reunión, acusas a todos de discriminadores (Sesgo Racial, Edad y Género) y exiges contratar a la Candidata B para llenar una "cuota demográfica".  
**Opción B:** Pides una pausa. En privado, te acercas al gerente principal (Speak up), le muestras cómo la falta de entrevistas estandarizadas (Contratación Moderna) permitió preguntas dispares, y sugieres invitar a dos líderes de otros departamentos (Opiniones Diversas) para reevaluar la decisión antes de proceder (Tomar Acción).  
**Opción C:** Aceptas la decisión (Sesgo de Conformidad) pero les envías anónimamente un artículo sobre Sesgos Inconscientes (Educación) para que lo lean en casa.

### **Evento 7: Ofrecer retroalimentación**  
**Retroalimentación inmediata basada en tu elección:**  
- **Si elegiste A:** *Incorrecto.* Contratar deliberadamente para llenar una cuota demográfica sin basarse en el mérito no es la solución, de hecho, es una forma de discriminación consciente directa. Además, avergonzarlos en público destruye la comunicación.
- **Si elegiste B:** *¡Excelente!* Aplicaste correctamente múltiples pasos: "Speak up" (hablando en privado), promoviste la "Contratación Moderna" (exigiendo estandarización), fomentaste "Opiniones Diversas" para romper la homogeneidad del comité y tomaste "Acción".
- **Si elegiste C:** *Incorrecto.* Enviar un artículo cubre la parte de "Educación", pero ceder al Sesgo de Conformidad significa que permitiste que la discriminación directa e indirecta ocurriera en el presente, afectando negativamente la vida y oportunidades de los Candidatos B y C.

### **Evento 8: Evaluar el desempeño**  
**Preguntas Situacionales Adicionales:**  
1. Si el equipo descartó el currículum del Candidato C al leer su nombre extranjero antes de siquiera conocerlo, ¿qué sub-categoría del sesgo de afinidad operó aquí además del Sesgo Racial? (Respuesta: Name Bias).  
2. ¿Qué sesgo cognitivo explica que el gerente le hiciera preguntas fáciles al candidato que ya le caía bien y preguntas trampa a la candidata mayor para justificar su rechazo? (Respuesta: Sesgo de Confirmación).

### **Evento 9: Mejorar la retención**  
**Infografía Resumen: Los 5 Pasos para Evitar Sesgos**  
*(Para descargar y mantener visible en el área de trabajo)*  
```mermaid
mindmap
  root((5 Estrategias
    Anti-Sesgos))
    Contratación Moderna
      Entrevistas estandarizadas
      Rúbricas ciegas
    Hablar en Privado
      Fomentar diálogo
      Señalar el sesgo
    Opiniones Diversas
      Grupos heterogéneos
      Múltiples perspectivas
    Tomar Acción
      Indagar motivos verdaderos
      Hacer preguntas incisivas
    Educación y Reflexión
      Investigar prejuicios
      Auto-reflexión
```

**Plan de Acción Personal:**  
Se invita al aprendiz a descargar una plantilla de "Entrevista Estandarizada" (Hire with a modern outlook) y un diagrama de flujo sobre cómo aplicar el paso "Speak Up" en privado la próxima vez que detecte un "snap judgment" (juicio apresurado) en su oficina.
