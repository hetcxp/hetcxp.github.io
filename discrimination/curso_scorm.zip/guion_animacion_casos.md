# Guion de Animación y Locución: Curso de Discriminación y Sesgos Inconscientes

**Objetivo:** Guion estructurado en clips de máximo 10 segundos (aprox. 20-25 palabras) para generación con Omni Flash.

---

## CASO 1: El Proceso de Contratación Seguro

**Estilo Visual Global:** Animación 3D estilizada (no hiperrealista).

### Requisitos de Assets (Personajes y Props)
- **Personajes:**
  - **Javier:** Reclutador junior. Joven, vestimenta casual de negocios. Expresión capaz de mostrar incomodidad.
  - **Comité (3):** Hombres idénticos (mismo traje oscuro, mismo peinado), proyectando rigidez.
  - **Candidato A:** Joven, sonriente, relajado.
  - **Candidata B:** Mujer mayor (50+), vestimenta profesional formal, seria.
  - **Candidato C:** Persona con vestimenta tradicional/cultural distintiva.
- **Entorno/Props:** Sala de juntas moderna, mesa, carpetas. Íconos flotantes 3D (Afinidad, Edad, Confirmación).

### Escena 1.1: La Sala de Juntas
- **Visual:** Javier (reclutador junior) sentado al fondo de una sala moderna, incómodo.
- **Audio (0-10s):** Conoce a Javier, un reclutador junior sentado en silencio en la sala de juntas.

### Escena 1.2: El Comité
- **Visual:** Frente a Javier, tres directivos idénticos (mismo traje y peinado).
- **Audio (0-10s):** Frente a él, un comité de directivos con perfil casi idéntico acaba de entrevistar a tres finalistas.

### Escena 1.3: Candidato A (Afinidad)
- **Visual:** Candidato A, joven y relajado. El comité asiente.
- **Audio (0-10s):** Al Candidato A, de la misma universidad que el gerente, le hicieron preguntas fáciles por pura simpatía.

### Escena 1.4: Candidata B (Edad)
- **Visual:** Candidata B, mujer mayor y seria. El comité la señala frunciendo el ceño.
- **Audio (0-10s):** A la Candidata B, con currículum brillante, la acorralaron buscando errores para justificar "falta de energía".

### Escena 1.5: Candidato C (Cultura)
- **Visual:** Candidato C, vestimenta tradicional. El comité rechaza su CV.
- **Audio (0-10s):** Al Candidato C lo descartaron por su vestimenta tradicional, asumiendo falsamente que "no encajaría en la cultura".

### Escena 1.6: El Dilema
- **Visual:** Primer plano de Javier dudando.
- **Audio (0-10s):** Sabiendo que el comité ya eligió injustamente al Candidato A, Javier siente un nudo en el estómago.

### Escena 1.7: Los Sesgos
- **Visual:** Íconos flotantes: "Afinidad", "Edad", "Confirmación".
- **Audio (0-10s):** La verdad es que todos tenemos sesgos. Aquí operan los de afinidad, edad y confirmación juntos.

### Escena 1.8: La Solución (Parte 1)
- **Visual:** Javier levanta la mano. Viñetas: "Contratación Moderna", "Hablar en privado".
- **Audio (0-10s):** Para evitar esto, debemos aplicar pasos clave: estandarizar entrevistas y hablar en privado para educar.

### Escena 1.9: La Solución (Parte 2)
- **Visual:** Viñetas: "Opiniones Diversas", "Tomar Acción", "Educación".
- **Audio (0-10s):** También hay que traer opiniones diversas, indagar en rechazos y educarnos sobre nuestros propios prejuicios.

---

## CASO 2: Dinámicas de Equipo y el Cumplido Incomprendido

**Estilo Visual Global:** Animación 3D estilizada (no hiperrealista).

### Requisitos de Assets (Personajes y Props)
- **Personajes:**
  - **Carlos:** Analista de origen étnico minoritario. Vestimenta moderna. Transición de orgullo a incomodidad.
  - **María:** Líder de equipo, mujer de mediana edad, postura de autoridad.
  - **Compañeros (2-3):** Personajes de fondo en la oficina.
- **Entorno/Props:** Oficina luminosa de planta abierta, laptop. Elementos UI 3D (Bocadillo de texto, barras flotantes de "Motivación" y "Confianza", gráfico "Método CPR").

### Escena 2.1: El Éxito
- **Visual:** Oficina luminosa. Equipo aplaudiendo a Carlos.
- **Audio (0-10s):** Conoce a Carlos. Tras semanas de esfuerzo entregando un proyecto impecable, el equipo se reúne para celebrar.

### Escena 2.2: La Intervención de la Líder
- **Visual:** María (la líder) se acerca a Carlos sonriendo.
- **Audio (0-10s):** De pronto, María, la líder del equipo, se dirige a él y le lanza un dardo disfrazado de halago.

### Escena 2.3: La Microagresión
- **Visual:** Bocadillo de texto de María: "Tu trabajo es tan bueno que casi me da vergüenza".
- **Audio (0-10s):** "Tu trabajo es tan bueno que casi me da vergüenza". El comentario tiene un tono sarcástico oculto.

### Escena 2.4: El Prejuicio
- **Visual:** Colores se apagan. Compañeros bajan la mirada.
- **Audio (0-10s):** Está enraizado en asumir falsamente que Carlos, por su origen étnico, "normalmente no rinde así".

### Escena 2.5: El Impacto
- **Visual:** Carlos fuerza sonrisa. Barras de "Motivación" bajando.
- **Audio (0-10s):** Carlos fuerza una sonrisa, pero por dentro siente cómo su motivación y confianza se desmoronan por completo.

### Escena 2.6: Efecto Espectador
- **Visual:** Silencio incómodo en la sala.
- **Audio (0-10s):** Esto es Discriminación por Percepción. Mientras tanto, el silencio del equipo valida la agresión, mostrando el "Efecto Espectador".

### Escena 2.7: El Método CPR
- **Visual:** Gráfico: C (Content), P (Pattern), R (Relationship).
- **Audio (0-10s):** ¿Cómo frenamos esto? Aplicando el Método CPR: Confrontar el incidente, detectar el patrón y cuidar la Relación.

### Escena 2.8: La Reunión Privada
- **Visual:** María y Carlos conversando en privado constructivamente.
- **Audio (0-10s):** Reunirse en privado para explicar cómo ese comentario destruyó la confianza es clave para un cambio real.

---

## CASO 3: La Decisión Rápida de Liderazgo

**Estilo Visual Global:** Animación 3D estilizada (no hiperrealista).

### Requisitos de Assets (Personajes y Props)
- **Personajes:**
  - **Elena:** Experta técnica, mujer de 65 años, vestimenta ejecutiva sobria, semblante de experiencia.
  - **CEO:** Hombre líder, actitud impaciente y autoritaria.
  - **Directivos:** Jóvenes con actitud impaciente y complaciente.
- **Entorno/Props:** Sala ejecutiva. Pantalla/proyector con gráficos 3D. Reloj digital gigante en la pared. Animación 3D abstracta de calendario pasando y monedas cayendo.

### Escena 3.1: La Urgencia
- **Visual:** Sala ejecutiva. Reloj gigante en "24:00:00".
- **Audio (0-10s):** Conoce a Elena, experta de 65 años. En una tensa reunión, solo quedan 24 horas para aprobar una inversión.

### Escena 3.2: La Presión
- **Visual:** CEO señala gráfico de riesgo. Todos asienten.
- **Audio (0-10s):** El CEO propone una ruta arriesgada de cinco millones. El grupo, ansioso por terminar, asiente de inmediato.

### Escena 3.3: La Alternativa Ignorada
- **Visual:** Elena muestra gráfico seguro ("Plan B"). El equipo cruza brazos.
- **Audio (0-10s):** Elena advierte con datos que hay una alternativa más segura, pero sus palabras flotan en el vacío.

### Escena 3.4: El Prejuicio de Edad y Género
- **Visual:** Rostros de jóvenes con desinterés.
- **Audio (0-10s):** Asumen que "sus ideas son obsoletas" y que, por ser mujer, "es demasiado cautelosa". Deciden ignorarla.

### Escena 3.5: El Fracaso
- **Visual:** Calendario avanza. Gráfico colapsa con monedas cayendo.
- **Audio (0-10s):** Al mes siguiente, la inversión se convierte en un fracaso millonario que pudo evitarse al escucharla.

### Escena 3.6: Anulando el Sesgo
- **Visual:** Tiempo retrocede a sala de juntas. CEO frena votación.
- **Audio (0-10s):** Aquí operó el sesgo de conformidad, género y edad. Nunca debemos priorizar la "cohesión" sobre los datos.

### Escena 3.7: Abogado del Diablo
- **Visual:** CEO pide a dos directivos defender la idea de Elena.
- **Audio (0-10s):** Frena la ansiedad grupal, juega al abogado del diablo y obliga al equipo a escuchar visiones divergentes.

---

## CASO 4: Construyendo el Futuro (Retención)

**Estilo Visual Global:** Animación 3D estilizada (no hiperrealista).

### Requisitos de Assets (Personajes y Props)
- **Personajes:**
  - **Luis:** Empleado con discapacidad visual (usa lentes oscuros o bastón blanco). Expresiones de cansancio/tristeza.
  - **Compañeros (2):** Personajes de fondo que ríen simulando burlas.
  - **Gerente:** Actitud fría y distante.
  - **Líder (Final):** Figura de liderazgo empática y cálida.
- **Entorno/Props:** Escritorio de oficina, oficina gerencial. Documento "Proyecto Estrella", caja de cartón. Gráfico 3D metafórico (puerta "Diversidad" y pista de baile "Inclusión").

### Escena 4.1: Las Burlas
- **Visual:** Luis (discapacidad visual) en escritorio. Compañeros simulando burlas.
- **Audio (0-10s):** Conoce a Luis, quien tiene discapacidad visual. Últimamente recibe insultos disfrazados de "bromas inofensivas".

### Escena 4.2: La Queja Formal
- **Visual:** Luis suspira agotado. Se levanta hacia RRHH.
- **Audio (0-10s):** No te confundas, esto no es un chiste: es acoso. Agotado, decide presentar una queja formal.

### Escena 4.3: La Exclusión
- **Visual:** Gerente aleja documento "Proyecto Estrella" de Luis.
- **Audio (0-10s):** A la semana, su gerente lo excluye sorpresivamente del proyecto más importante del año.

### Escena 4.4: La Justificación Injusta
- **Visual:** Luis se muestra sorprendido y triste.
- **Audio (0-10s):** El gerente argumenta: "Mejor no participes, no queremos ofenderte más ni gastar recursos en adaptarlo".

### Escena 4.5: La Renuncia
- **Visual:** Luis empacando sus cosas.
- **Audio (0-10s):** Sintiéndose castigado por haberse quejado ante Recursos Humanos, Luis renuncia a su puesto al día siguiente.

### Escena 4.6: Diversidad vs Inclusión
- **Visual:** Gráfico: Puerta ("Diversidad") y pista de baile ("Inclusión").
- **Audio (0-10s):** Excluir por denunciar es Victimización. Diversidad es invitar a la fiesta; inclusión es invitar a bailar.

### Escena 4.7: Estrategias del Líder
- **Visual:** Líder contando historia a su equipo.
- **Audio (0-10s):** Para retener talento, el líder debe mostrar vulnerabilidad, evitar aislar empleados y crear canales de retroalimentación seguros.
