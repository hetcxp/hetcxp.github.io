## Caso 4: Construyendo el Futuro (Estrategias de Retención e Inclusión)

### 1. Captar la atención
**Lectura de Escenario Inmersivo:**  
*Conoce a Luis, un empleado con discapacidad visual.*

*Recientemente, Luis ha comenzado a recibir chistes ofensivos e insultos disfrazados de "bromas inofensivas" por parte de sus compañeros de equipo respecto a su condición.*

*Esto es **Acoso**.*

*Agotado, Luis decide presentar una queja formal a Recursos Humanos.*

*A la semana siguiente, su gerente lo excluye sorpresivamente del proyecto más importante del año, argumentando: "Mejor no participes, no queremos ofenderte más ni invertir recursos en adaptar la plataforma para ti".*

*Luis, sintiéndose castigado por quejarse, renuncia al día siguiente.*

### 2. Informar al aprendiz
**Objetivo del módulo:**  
Aprenderás a diferenciar el **Acoso** (Harassment) de la **Victimización**, comprenderás cómo la falta de inclusión destruye la retención de talento, y revisarás 4 estrategias conductuales clave que todo líder debe aplicar para fomentar un entorno seguro.

### 3. Estimular el recuerdo
**Actividad de Autorreflexión (Flip Card):**  
- **Instrucción:** Piensa en tu organización. ¿Has notado que la diversidad no siempre se traduce en inclusión? (Escribe tu respuesta y presiona "Revelar concepto").
- **Respuesta a revelar:** La diversidad es invitar a alguien a la fiesta; la inclusión es invitarlo a bailar. Contratar diversidad sin fomentar inclusión (y permitir acosos o victimización) inevitablemente provoca la fuga de talento.

### 4. Presentar el contenido
**Análisis Conceptual:**  
- **Acoso (Harassment):** Comportamientos dirigidos a intimidar u ofender directamente a alguien por sus características (ej. los chistes ofensivos hacia Luis).
- **Victimización:** Represalias o trato injusto hacia alguien *porque se atrevió a denunciar* una discriminación (ej. excluir a Luis del proyecto por quejarse).
- **El Impacto Oculto:** Ambas acciones generan desconfianza, estrés crónico y alta rotación. La empresa perdió a un talento valioso por no saber manejar la denuncia.

### 5. Proporcionar guía de aprendizaje
**Estrategias Conductuales para Líderes:**  
Para evitar que situaciones como la de Luis se repitan, los líderes deben modelar la inclusión mediante acciones conductuales:
1. **Contar historias personales:** Un líder que comparte abiertamente cuándo se equivocó con un sesgo en el pasado y cómo lo superó, crea un entorno de seguridad psicológica.
2. **Examinar procesos de pensamiento:** Pausar antes de tomar decisiones (como asignar proyectos) para cuestionar: "¿Estoy excluyendo a Luis por sesgos o represalias?".
3. **Esfuerzo por aprender:** Educarse proactivamente sobre cómo hacer adaptaciones razonables para personas con discapacidad, en lugar de verlo como un "gasto".
4. **Buscar retroalimentación constante:** Crear canales anónimos y seguros para que el equipo reporte acosos sin miedo a represalias.

### 6. Provocar el desempeño
**Escenario Interactivo de Toma de Decisión:**  
Eres el Director de Operaciones. Te enteras de la renuncia de Luis y descubres que fue víctima de acoso y posterior victimización por parte del gerente. Decides intervenir para reparar la cultura. ¿Qué estrategia conductual aplicas primero?
a) Redactas un nuevo manual de código de conducta y lo envías por correo (Estrategia estructural).
b) Organizas una reunión de equipo donde compartes una historia personal sobre un error que cometiste en el pasado respecto a la inclusión, mostrando vulnerabilidad, y abres un canal seguro para escuchar al equipo (Contar historias personales / Buscar retroalimentación).
c) Buscas a Luis y lo amenazas para que no publique su renuncia en redes sociales (Victimización adicional).

### 7. Ofrecer retroalimentación
**Retroalimentación inmediata:**  
- **Si eligió a):** *Incorrecto para este objetivo.* Un manual es útil, pero es una estrategia *estructural*, no conductual. Se necesita modelar con el ejemplo humano.
- **Si eligió b):** *¡Correcto!* Contar historias personales mostrando vulnerabilidad es una de las estrategias conductuales más poderosas para derribar barreras y fomentar la confianza perdida.
- **Si eligió c):** *Incorrecto.* Esto es agravar el problema y garantizar una crisis de reputación para la empresa.

### 8. Evaluar el desempeño
**Quiz Interactivo:**  
1. Los chistes ofensivos recurrentes que recibió Luis sobre su condición visual constituyen:
   - a) Discriminación Indirecta
   - b) Acoso (Harassment) *(Correcta)*
   - c) Microagresión sistémica
2. La exclusión del proyecto como castigo por haber presentado la queja en Recursos Humanos es un ejemplo de:
   - a) Victimización *(Correcta)*
   - b) Efecto Espectador
   - c) Sesgo de Confirmación

### 9. Mejorar la retención
**Infografía Resumen: Estrategias Conductuales e Inclusión**  
*(Para descargar y mantener visible en el área de trabajo)*  
```mermaid
mindmap
  root((Estrategias de
    Inclusión))
    Conceptos Clave
      Acoso (Harassment)
      Victimización
      Inclusión vs Diversidad
    Impacto Oculto
      Estrés crónico
      Alta rotación
      Pérdida de talento
    Acciones del Líder
      Contar historias personales
      Examinar procesos de decisión
      Educarse sobre adaptaciones
      Buscar retroalimentación constante
```

**Herramienta Interactiva de Compromiso:**  
- **Actividad:** Se presenta un recuadro de texto: *"Escribe 1 acción conductual (como pedir retroalimentación o contar una historia) que te comprometes a realizar esta semana con tu equipo"*.
- **Cierre:** Al enviarlo, el sistema genera automáticamente un **Certificado en PDF** de "Compromiso de Liderazgo Inclusivo" con el nombre del usuario y su acción elegida, listo para descargar o imprimir.
