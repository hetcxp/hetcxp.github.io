# Módulo: Microagresiones en Dinámicas de Equipo  
## Caso 2: Dinámicas de Equipo y el Cumplido Incomprendido  

### 1. Captar la atención  
**Lectura de Escenario Inmersivo:**  
*Conoce a Carlos, un dedicado analista en una multinacional.*

*Tras semanas de arduo esfuerzo entregando un proyecto impecable, el equipo se reúne para celebrar.*

*De pronto, María, la líder del equipo, se dirige a él y frente a todos le lanza un dardo disfrazado de halago: "Tu trabajo es tan bueno que casi me da vergüenza".*

*El comentario, cargado de un tono sarcástico y enraizado en la suposición errónea de que Carlos pertenece a una minoría étnica que "normalmente no rinde así", deja la sala en un silencio incómodo.*

*Nadie dice nada.*

*Carlos fuerza una sonrisa, pero por dentro siente cómo la motivación se desmorona y la desconfianza hacia su líder se arraiga.*

### 2. Informar al aprendiz  
- **Conceptos clave**: Microagresiones, Discriminación por Asociación y Discriminación por Percepción.  
- **Caso**:  
  - **Contenido (Incidente)**: María, líder del equipo, comenta: *"Tu trabajo es tan bueno que casi me da vergüenza"* al finalizar un proyecto.  
  - **Patrón**: Este tipo de cumplido se repite en reuniones, siempre con tono sarcástico.  
  - **Relación**: María asume erróneamente que Carlos es de una etnia particular y lo trata de forma injusta basándose en ese prejuicio, a pesar de que Carlos no pertenece a dicho grupo (**Discriminación por Percepción**).  

### 3. Estimular el recuerdo  
- **Actividad de Autorreflexión (Interactive Text / Flip Card)**:  
  - Se le presenta al usuario un recuadro de texto para responder brevemente a la pregunta: *¿Qué elementos del caso reflejan microagresiones y cómo crees que afectan a las dinámicas de equipo?*  
  - Al hacer clic en "Revelar respuesta", el sistema le muestra la comparación para el autoconsumo:  
    - **Microagresión**: El "cumplido" con tono sarcástico basado en el origen étnico ("casi me da vergüenza").  
    - **Efecto esperado**: Genera estrés crónico, hipervigilancia en Carlos y quiebra la confianza del equipo.

### 4. Presentar el contenido  
- **Análisis de microagresiones**:  
  - **Discriminación por asociación**: Carlos es blanco de comentarios despectivos por estar en un equipo con miembros discriminados.  
  - **Percepción**: María asume que Carlos pertenece a un grupo "no deseado".  
  - **Barreras**: Dificultad para identificar el comentario como agresivo y renuencia a actuar por el efecto espectador.  

### 5. Proporcionar guía de aprendizaje  
- **Metodología CPR**:  
  - **Contenido (Incidente)**: Identificar el cumplido como una microagresión.  
  - **Patrón**: Reconocer que este comportamiento es recurrente y sistémico.  
  - **Relación**: Vincular el incidente con actitudes de discriminación y percepciones erróneas.  

### 6. Provocar el desempeño  
**Escenario Interactivo:**  
Al escuchar el comentario de María ("casi me da vergüenza"), tú decides aplicar el método CPR para confrontarla. ¿Qué enfoque eliges?
a) (Content) Le dices frente a todos: "Ese comentario es inapropiado hoy."
b) (Relationship) Te reúnes en privado con ella y le dices: "Cuando haces ese tipo de comentarios, dañas la confianza del equipo hacia ti y haces que Carlos se sienta excluido."
c) (Pattern) Te quedas callado asumiendo el efecto espectador, pensando que alguien más dirá algo.

### 7. Ofrecer retroalimentación  
**Retroalimentación inmediata:**  
- **Si eligió a):** *Parcialmente correcto.* Confrontar el incidente (Content) es un inicio, pero hacerlo en público pone a la defensiva a la persona y no resuelve el daño profundo.
- **Si eligió b):** *Correcto.* Enfocarte en la Relación de manera privada es la forma más efectiva del CPR, pues ataca la raíz del problema y ayuda al perpetrador a recapacitar.
- **Si eligió c):** *Incorrecto.* Ser un espectador pasivo perpetúa el ciclo de las microagresiones.

### 8. Evaluar el desempeño  
**Quiz Interactivo (Selección Simple):**  
1. En el caso analizado, cuando María asume que Carlos pertenece a un grupo discriminado y, por estar cerca de él, sus compañeros también reciben comentarios despectivos, ¿qué fenómeno está ocurriendo?
   - a) Microagresión sistémica
   - b) Discriminación por asociación *(Correcta)*
   - c) Sesgo de Confirmación

2. ¿Cuál es la principal barrera que explica por qué los compañeros de Carlos no intervienen inmediatamente tras el comentario de María?
   - a) Efecto Espectador *(Correcta)*
   - b) Falta de capacitación
   - c) Estrés crónico

3. Si María trata injustamente a Carlos porque cree erróneamente que él pertenece a un grupo étnico específico, ¿qué tipo de discriminación está ejerciendo?
   - a) Discriminación Indirecta
   - b) Discriminación por Percepción *(Correcta)*
   - c) Discriminación por Asociación

### 9. Mejorar la retención  
**Infografía Resumen: Microagresiones y Método CPR**  
*(Para descargar y mantener visible en el área de trabajo)*  
```mermaid
mindmap
  root((Defensa ante
    Microagresiones))
    Tipos Comunes
      Discriminación por Asociación
      Asunciones Estereotipadas
      Cumplidos Sarcásticos
    Impacto Oculto
      Estrés Crónico
      Hipervigilancia
      Pérdida de Confianza
    Método CPR
      Content (Incidente)
        Abordar el comentario único
      Pattern (Patrón)
        Abordar la repetición constante
      Relationship (Relación)
        Abordar el daño a la confianza
    Barreras a Superar
      Efecto Espectador
```

- **Reflexión final descargable**:  
  - ¿Cómo puede un líder mitigar microagresiones en el equipo? Fomentar el diálogo abierto, educar sobre discriminación y crear un entorno seguro para reportar incidentes.  
