function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5p6G08WBhag":
        Script1();
        break;
      case "6Sq255DEe8q":
        Script2();
        break;
      case "5tzGQZchTOC":
        Script3();
        break;
      case "63VnzgoWh6k":
        Script4();
        break;
      case "5dlsbDNnG1l":
        Script5();
        break;
      case "6JY5MriAR7Y":
        Script6();
        break;
      case "64ISIEPeQVV":
        Script7();
        break;
      case "5pFyrrHseMV":
        Script8();
        break;
      case "6pTG8PdVr1I":
        Script9();
        break;
  }
}

function Script1()
{
  var myWindow = window.open("","Print","width=810,height=610,scrollbars=1,resizable=1");
var player=GetPlayer();
var headline=player.GetVar("PrintTitle");
var date=player.GetVar("SystemDate");
var usernotes=player.GetVar("notes");
var exercisenotes1=player.GetVar("notes11");
var exercisenotes2=player.GetVar("notes22");
var exercisenotes3=player.GetVar("notes33");var exercisenotes4=player.GetVar("notes44")
var contents = "<html><head></head><body style='width:650px;padding:20px;'>"
contents += "<div style='height:20px;padding:10px;margin-bottom:20px;text-align:center;'><button onclick='javascript:window.print();'>Print My Notes</button></div>";
contents+="<div style='font-size:22px;font-weight:bold;margin-top:20px;margin-bottom:20px;'>"+headline+"</div>";
contents+="<div style='font-size:16px;'>"+date+"</div>";
contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>Professional Services Firm</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+exercisenotes1+"</div>";
contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>Activity Notes - 2</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+exercisenotes2+"</div>";
contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>Activity Notes - 3</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+exercisenotes3+"</div>";contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>Activity Notes - 4</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+exercisenotes4+"</div>";
contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>General Notes</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+usernotes+"</div>";
contents+= "</body></html>"
myWindow.document.write(contents);
}

function Script2()
{
  window.print()
}

function Script3()
{
  window.print()
}

function Script4()
{
  var myWindow = window.open("","Print","width=810,height=610,scrollbars=1,resizable=1");
var player=GetPlayer();
var headline=player.GetVar("PrintTitle");
var date=player.GetVar("SystemDate");
var usernotes=player.GetVar("notes");
var exercisenotes1=player.GetVar("notes11");
var exercisenotes2=player.GetVar("notes22");
var exercisenotes3=player.GetVar("notes33");var exercisenotes4=player.GetVar("notes44")
var contents = "<html><head></head><body style='width:650px;padding:20px;'>"
contents += "<div style='height:20px;padding:10px;margin-bottom:20px;text-align:center;'><button onclick='javascript:window.print();'>Print My Notes</button></div>";
contents+="<div style='font-size:22px;font-weight:bold;margin-top:20px;margin-bottom:20px;'>"+headline+"</div>";
contents+="<div style='font-size:16px;'>"+date+"</div>";
contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>Professional Services Firm</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+exercisenotes1+"</div>";
contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>Activity Notes - 2</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+exercisenotes2+"</div>";
contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>Activity Notes - 3</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+exercisenotes3+"</div>";contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>Activity Notes - 4</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+exercisenotes4+"</div>";
contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>General Notes</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+usernotes+"</div>";
contents+= "</body></html>"
myWindow.document.write(contents);
}

function Script5()
{
  window.print()
}

function Script6()
{
  window.print()
}

function Script7()
{
  var myWindow = window.open("","Print","width=810,height=610,scrollbars=1,resizable=1");
var player=GetPlayer();
var headline=player.GetVar("PrintTitle");
var date=player.GetVar("SystemDate");
var usernotes=player.GetVar("notes");
var exercisenotes1=player.GetVar("notes11");
var exercisenotes2=player.GetVar("notes22");
var exercisenotes3=player.GetVar("notes33");var exercisenotes4=player.GetVar("notes44")
var contents = "<html><head></head><body style='width:650px;padding:20px;'>"
contents += "<div style='height:20px;padding:10px;margin-bottom:20px;text-align:center;'><button onclick='javascript:window.print();'>Print My Notes</button></div>";
contents+="<div style='font-size:22px;font-weight:bold;margin-top:20px;margin-bottom:20px;'>"+headline+"</div>";
contents+="<div style='font-size:16px;'>"+date+"</div>";
contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>Professional Services Firm</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+exercisenotes1+"</div>";
contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>Activity Notes - 2</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+exercisenotes2+"</div>";
contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>Activity Notes - 3</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+exercisenotes3+"</div>";contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>Activity Notes - 4</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+exercisenotes4+"</div>";
contents+="<div style='font-size:18px;font-weight:bold;margin-top:10px;'>General Notes</div>";
contents+="<div style='font-size:17px;margin-top:5px;'>"+usernotes+"</div>";
contents+= "</body></html>"
myWindow.document.write(contents);
}

function Script8()
{
  window.print()
}

function Script9()
{
  window.print()
}

